﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using NUnit.Framework;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;
// For supporting Page Object Model
// Obsolete - using OpenQA.Selenium.Support.PageObjects;
using SeleniumExtras.PageObjects;

namespace MercuryTours
{
    class LoginPage
    {
        private IWebDriver driver;
        Int32 timeout = 10000; // in milliseconds

        public LoginPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//*[@id='app']/div/div/div/div/form/div[1]/input")]
        private IWebElement elem_lt_login_user_name;

        [FindsBy(How = How.XPath, Using = "//*[@id='userpassword']")]
        private IWebElement elem_lt_login_password;

        [FindsBy(How = How.XPath, Using = "//*[@id='app']/div/div/div/div/form/div[3]/button")]
        private IWebElement elem_lt_login_button;

        // Returns the Page Title
        public String getPageTitle()
        {
            return driver.Title;
        }

        async void async_delay(int delay)
        {
            await Task.Delay(delay);
        }

        public void wait_page_completion(int timeout)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(timeout));

            // Wait for the page to load
            wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));
        }

        public void send_userpassword(String user_name, String password)
        {
            //As the page load is already complete, we can directly enter the user name and password
            elem_lt_login_user_name.SendKeys(user_name);
            async_delay(50);
            elem_lt_login_password.SendKeys(password);
            async_delay(50);
        }

        public FinalPage submit_uidpwd()
        {
            elem_lt_login_button.Click();

            // Wait for the new page to load. This is the LambdaTest dashboard
            wait_page_completion(timeout);

            return new FinalPage(driver);
        }
    }
}