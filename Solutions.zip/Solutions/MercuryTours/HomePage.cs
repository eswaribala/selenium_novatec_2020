﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using NUnit.Framework;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;

using SeleniumExtras.PageObjects;

namespace MercuryTours
{
    class HomePage
    {
        String test_url = "https://www.lambdatest.com/";

        private IWebDriver driver;
        private WebDriverWait wait;
        Int32 timeout = 10000; // in milliseconds

        public HomePage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/header/div[3]/nav/a/img")]
        private IWebElement elem_lt_logo;

        [FindsBy(How = How.XPath, Using = "//*[@id='navbarSupportedContent']/ul/li[7]/a]")]
        private IWebElement elem_lt_signup;

        [FindsBy(How = How.LinkText, Using = "Log in")]
        private IWebElement elem_lt_login;

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Automation')]")]
        private IWebElement elem_lt_automation;

        async void async_delay()
        {
            await Task.Delay(50);
        }

        public void wait_page_completion(int timeout)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(timeout));

            // Wait for the page to load
            wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));
        }

        // Go to the designated page
        public void goToPage()
        {
            driver.Navigate().GoToUrl(test_url);
        }

        // Returns the Page Title
        public String getPageTitle()
        {
            return driver.Title;
        }

        // Checks whether the Logo is displayed properly or not
        public bool getHomePageLogo()
        {
            return elem_lt_logo.Displayed;
        }

        public String getHomePageAttribute(String input_attribute)
        {
            return elem_lt_logo.GetAttribute(input_attribute);
        }

        public LoginPage goToLoginPage()
        {
            elem_lt_login.Click();

            //Delay added to ensure that the page load is complete
            //We can also use non-blocking delay of the same time
            //but using the DOM state is more advantageous

            //async_delay();
            wait_page_completion(timeout);
            return new LoginPage(driver);
        }
    }
}