﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace MercuryTours
{
    class ResourceHelper
    {

        public static Hashtable GetKeyandValues()
        {
            String url=ConfigurationManager.AppSettings["url"];
            String openemrurl= ConfigurationManager.AppSettings["openemrurl"];
            String driver= ConfigurationManager.AppSettings["driver"];
            String expectedTitle = ConfigurationManager.AppSettings["expectedTitle"];
            String userName = ConfigurationManager.AppSettings["userName"];
            String password = ConfigurationManager.AppSettings["password"];
            String loginQuery= ConfigurationManager.AppSettings["loginQuery"];
            Hashtable hashTable = new Hashtable();
            hashTable.Add("url", url);
            hashTable.Add("driver", driver);
            hashTable.Add("expectedTitle", expectedTitle);
            hashTable.Add("userName", userName);
            hashTable.Add("password", password);
            hashTable.Add("openemrurl", openemrurl);
            hashTable.Add("loginQuery", loginQuery);
            return hashTable;

        }


        public static SqlConnection GetConnection()
        {
            String connString = ConfigurationManager.ConnectionStrings["svsconn"].ConnectionString;
            return new SqlConnection(connString);
        }

    }
}
