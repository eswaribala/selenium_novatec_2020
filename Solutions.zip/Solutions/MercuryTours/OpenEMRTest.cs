﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using OpenQA.Selenium.Interactions;
using System.Text.RegularExpressions;
using Excel = Microsoft.Office.Interop.Excel;
namespace MercuryTours
{
    [TestFixture]
    class OpenEMRTest
    {
        private IWebDriver webDriver;
        private String test_url;
        private static Hashtable hashtable;
        private static SqlConnection sqlConnection;
        private static SqlCommand sqlCommand;
        private static SqlDataReader sqlDataReader;
        private Excel.Application excelApp;
        private Excel.Workbook excelWorkbook,excelWorkbookOut;
        private Excel.Worksheet excelWorkSheet, excelWorkSheetOut;
        public IDictionary<string, object> vars { get; private set; }
        private IJavaScriptExecutor js;

        [SetUp]
        public void Initialie()
        {
            hashtable = ResourceHelper.GetKeyandValues();
            webDriver = new ChromeDriver(hashtable["driver"].ToString());
            test_url= hashtable["openemrurl"].ToString();

        }

        [Test,TestCaseSource("DBData")]
        public void LoginTestUsingDataTable(String data1, String data2)
        {
            webDriver.Url = test_url;
            Debug.WriteLine(data1, data2);
            //username and password should be in alphabets
            String userNamePattern = "^[A-Za-z]*$";
            Assert.IsTrue(Regex.IsMatch(data1, userNamePattern));
            if (Regex.IsMatch(data1, userNamePattern))
            {
                webDriver.FindElement(By.Id("authUser")).SendKeys(data1);
                webDriver.FindElement(By.Id("clearPass")).SendKeys(data2);
                webDriver.FindElement(By.CssSelector("button[class='btn btn-default btn-lg']")).Click();
            }
        }
        [Test]
        public void PasswordTest()
        {
            //String passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[*.!@$%^&(){}[]:;<>,.?/~_+-=|\\]).{7,32}$";
            String passwordPattern = "^[a-zA-z@$!0-9]{7,32}$";
            String fileName = "G:/Local disk/TDD/PasswordData_v2.xlsx";
            string outFileName = "G:/Local disk/TDD/PasswordTestResult.xlsx";
            excelApp = new Excel.Application();
            if (excelApp != null)
            {
                excelWorkbook = excelApp.Workbooks.Open(fileName);
                excelWorkSheet = (Excel.Worksheet)excelWorkbook.Sheets[1];
                excelWorkbookOut = excelApp.Workbooks.Open(outFileName);
                excelWorkSheetOut = (Excel.Worksheet)excelWorkbookOut.Sheets[1];

                Excel.Range excelRange = excelWorkSheet.UsedRange;
                int rowCount = excelRange.Rows.Count;
                int colCount = excelRange.Columns.Count;
                String cellValue;
                Excel.Range range;
                for (int row = 2; row <= rowCount; row++)

                {
                    range = (excelWorkSheet.Cells[row, 1] as Excel.Range);
                    if (range.Value != null)
                    {
                        cellValue = range.Value.ToString();
                        Debug.WriteLine(cellValue);
                        Assert.IsTrue(Regex.IsMatch(cellValue, passwordPattern));
                        excelWorkSheetOut.Cells[row, 1] = cellValue;
                        excelWorkSheetOut.Cells[row, 2] = passwordPattern;
                        excelWorkSheetOut.Cells[row, 3] ="Passed";
                    }
                }
            }

            excelWorkbookOut.Save();



            }
        private static IEnumerable<String[]> DBData()
        {
            sqlConnection = ResourceHelper.GetConnection();
            sqlConnection.Open();
            hashtable = ResourceHelper.GetKeyandValues();
            using(sqlConnection)
            {
                sqlCommand = new SqlCommand(hashtable["loginQuery"].ToString(), sqlConnection);
                sqlDataReader=sqlCommand.ExecuteReader();
                while(sqlDataReader.HasRows)
                {
                    Debug.WriteLine("\n{0},\t{1}",sqlDataReader.GetName(0), sqlDataReader.GetName(1));
                    while(sqlDataReader.Read())
                    {
                        Debug.WriteLine("\n{0},\t{1}",sqlDataReader.GetString(0), sqlDataReader.GetString(1));
                        yield return new string[] { sqlDataReader.GetString(0), sqlDataReader.GetString(0) };
                    }
                    sqlDataReader.NextResult();

                }


            }

            
        }


        [Test]
        public void ShadowRootest()
        {

            webDriver.Url="chrome://downloads/";


            IWebElement root1 = webDriver.FindElement(By.TagName("downloads-manager"));

            //Get shadow root element
            IWebElement shadowRoot1 = expandRootElement(root1);

            IWebElement root2 = shadowRoot1.FindElement(By.CssSelector("downloads-toolbar"));
            IWebElement shadowRoot2 = expandRootElement(root2);

            IWebElement root3 = shadowRoot2.FindElement(By.CssSelector("cr-toolbar"));
            IWebElement shadowRoot3 = expandRootElement(root3);

           // String actualHeading = shadowRoot3.FindElement(By.CssSelector("div[id=leftContent]>h1")).Text;
            // Verify header title
            //Assert.Equals("Downloads", actualHeading);


        }


    [Test]
    public void JSTest()
        {
            // open webpage

        webDriver.Url="https://chercher.tech/java/javascript-executor-selenium-webdriver";

            js = (IJavaScriptExecutor)webDriver;

            // get the maximum scroll distance Horizontally
            Object horizontalScrollBar = js.ExecuteScript("return window.scrollMaxX");

            // get the maximum scroll distance Vertically
            Object verticalScrollBar = js.ExecuteScript("return window.scrollMaxY");

            

        }


        [Test]
        public void ActionScript()
        {
            webDriver.Url="http://demo.guru99.com/test/newtours/";
            IWebElement link_Home = webDriver.FindElement(By.LinkText("Home"));
            IWebElement td_Home = webDriver
                    .FindElement(By
                    .XPath("//html/body/div"
                    + "/table/tbody/tr/td"
                    + "/table/tbody/tr/td"
                    + "/table/tbody/tr/td"
                    + "/table/tbody/tr"));

            Actions builder = new Actions(webDriver);
            IAction  mouseOverHome = builder
                    .MoveToElement(link_Home)
                    .Build();

            String bgColor = td_Home.GetCssValue("background-color");
            Debug.WriteLine("Before hover: " + bgColor);
            mouseOverHome.Perform();
            bgColor = td_Home.GetCssValue("background-color");
          Debug.WriteLine("After hover: " + bgColor);
        }


    public IWebElement expandRootElement(IWebElement element)
        {
            IWebElement ele = (IWebElement)((IJavaScriptExecutor)webDriver)
    .ExecuteScript("return arguments[0].shadowRoot", element);
            return ele;
        }

        [TearDown]
        public void CloseConnection()
        {
            webDriver.Close();
           // excelWorkbook.Close();
            //excelWorkbookOut.Close();

        }




    }
}
