﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemoApp
{
    class NewToursTest
    {
        IWebDriver driver;

        [SetUp]
        public void startBrowser()
        {
            driver = new ChromeDriver("G:\\Local disk\\selenium\\" +
                "chromedriver_win32");
        }

        [Test]
        public void test()
        {
            driver.Url = "http://newtours.demoaut.com/";
        }

        [TearDown]
        public void closeBrowser()
        {
            driver.Close();
        }

    }
}
