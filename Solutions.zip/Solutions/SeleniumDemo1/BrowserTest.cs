﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    [TestFixture]
    public class BrowserTest
    {
        private IWebDriver webDriver;
        private IWebElement element;
        private String test_url;
        [SetUp]
        public void InitialSetup()
        {
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            webDriver.Manage().Window.Maximize();
            test_url = "https://www.royalsundaram.in/";
        }

        [Test]
        public void TestOpenBrowser()
        {
            webDriver.Url = test_url;
        }
        [Test]
        public void TestTitle()
        {
            String expected = "Buy or Renew Health, Travel & " +
                  "Motor Insurance Online | Royal Sundaram";
            webDriver.Url = test_url;          
            String actual = webDriver.Title;
            Assert.AreEqual(expected, actual);

        }

        [Test]
        public void TestClosePopup()
        {
            webDriver.Url = test_url;

            String actual = "";
            foreach(String winHandle in webDriver.WindowHandles)
            {
                webDriver.SwitchTo().Window(winHandle);
                WebDriverWait wait = new WebDriverWait(webDriver, new TimeSpan(2000));
              
                    IWebElement element = wait.Until(drv => drv.FindElement
                    (By.ClassName("rsgi-close")));
                    if (element.Displayed)
                    {
                        element.Click();
                        actual = webDriver.FindElement(By.CssSelector("h1[class='welcomenote welcomenote_home']")).Text;
                        Assert.IsTrue(actual.Contains("Welcome To"));
                    }
                                
                }
            }


        [TearDown]
        public void CloseBrowser()
        {
            webDriver.Close();
        }
    }
}
