﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    [TestFixture]
    class DownloadFileDemo
    {


        private IWebDriver webDriver;
        private String test_url;
        [SetUp]
        public void InitialSetup()
        {
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            webDriver.Manage().Window.Maximize();
            test_url = "http://brownscourt.com/menus/bread/";
        }

        [Test]
        public void FileUploadTest()
        {
            webDriver.Url = test_url;
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
             IWebElement downloadFile = webDriver.FindElement(By.CssSelector("div[class='button medium left']"));
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
            IWebElement anchorElement= downloadFile.FindElement(By.TagName("a"));
            anchorElement.Click();
          
            WebDriverWait wait = new WebDriverWait(webDriver, new TimeSpan(15000));
            Debug.WriteLine(webDriver.Url);
            Assert.AreEqual(webDriver.Url, "http://brownscourt.com/wp-content/themes/skeleton_wp-standalone/skeleton/images/bc-ordering-menu-01.pdf");
            
        }


        [TearDown]
        public void CleanUp()
        {
            webDriver.Close();
        }

    }
}
