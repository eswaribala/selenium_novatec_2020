﻿using LumenWorks.Framework.IO.Csv;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace SeleniumDemo1
{
    [TestFixture]
    class DataDrivenTestDemo
    {


        private IWebDriver webDriver;
        private String test_url;
        [SetUp]
        public void InitialSetup()
        {
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            webDriver.Manage().Window.Maximize();
            test_url = "http://www.newtours.demoaut.com/";
        }

        [Test, TestCaseSource("GetDataFromTable")]
        public void Log_Test(String data1, String data2)
        {
            webDriver.Url = test_url;
            // Get the WebElement corresponding to the Email Address(TextField)		
            IWebElement userName = webDriver.FindElement(By.Name("userName"));

            // Get the WebElement corresponding to the Password Field		
            IWebElement password = webDriver.FindElement(By.Name("password"));

            userName.SendKeys(data1);

            password.SendKeys(data2);


            // Find the submit button		
            IWebElement login = webDriver.FindElement(By.Name("login"));
            login.Click();



        }

        private static IEnumerable<String[]> GetTestData()
        {
            FileStream fs = new FileStream("G:/Local disk/TDD/test-data.csv", FileMode.Open, FileAccess.Read);
            using (var csv = new CsvReader(new StreamReader(fs), true))
            {
                while (csv.ReadNextRecord())
                {
                    String data1 = csv[0];
                    String data2 = csv[1];
                    yield return new[] { data1, data2 };
                }
            }
        }

        [Test]
        public void GetTestDataExcel()
        {
            Excel.Application excelApp = new Excel.Application();
            if (excelApp != null)
            {
                Excel.Workbook excelWorkbook = excelApp.Workbooks.Open(@"G:\Local disk\TDD\login-test.xlsx", 0, true, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
                Excel.Worksheet excelWorksheet = (Excel.Worksheet)excelWorkbook.Sheets[1];

                Excel.Range excelRange = excelWorksheet.UsedRange;
                int rowCount = excelRange.Rows.Count;
                int colCount = excelRange.Columns.Count;

                for (int i = 1; i <= rowCount; i++)
                {
                    for (int j = 1; j <= colCount; j++)
                    {
                        Excel.Range range = (excelWorksheet.Cells[i, 1] as Excel.Range);
                        string cellValue = range.Value.ToString();

                        //do anything
                    }
                }

                excelWorkbook.Close();
                excelApp.Quit();
            }
        }

        public static IEnumerable<String[]> GetDataFromTable()
        {


            SqlConnection conn = SQLHelper.GetConnection();
            using (conn)
            {
                SqlCommand command = new SqlCommand(
                  "SELECT * from DemoUser;",conn);
                conn.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.HasRows)
                {
                    Console.WriteLine("\t{0}\t{1}", reader.GetName(0),
                        reader.GetName(1));

                    while (reader.Read())
                    {
                        Console.WriteLine("\t{0}\t{1}", reader.GetString(0),
                            reader.GetString(1));
                        yield return new[] { reader.GetString(0), reader.GetString(1) };
                    }
                    reader.NextResult();
                }
            }

        }

    }
}
