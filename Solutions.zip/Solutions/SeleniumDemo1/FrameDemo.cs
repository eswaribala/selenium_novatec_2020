﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    [TestFixture]
    class FrameDemo
    {
        private IWebDriver webDriver;
        private String test_url;
        [SetUp]
        public void InitialSetup()
        {
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            webDriver.Manage().Window.Maximize();
            test_url = "http://demo.guru99.com/test/guru99home/";
        }

        [Test]
        public void SwitchToFrame()
        {
            webDriver.Url = test_url;
            // navigates to the page consisting an iframe

            webDriver.Manage().Window.Maximize();

            webDriver.Manage().Timeouts().ImplicitWait= TimeSpan.FromSeconds(1000);

            int size = webDriver.FindElements(By.TagName("iframe")).Count;
            Console.WriteLine("Total Frames --" + size);

            
        }


        [Test]
        public void FrameLeftTest()
        {
            String test_url = "http://the-internet.herokuapp.com/nested_frames";

            WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(10));

            webDriver.Url = test_url;

            /**************** Switching to the Left Frame ****************/
            /* Switch to the Parent frame before switching to any of the Child frames */
            webDriver.SwitchTo().ParentFrame();

            /* Since the top frame is a Framset, switch to that frameset first */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector
                ("[name = 'frame-top']")));

            /* As we are already in the frameset, we can now switch to the new frame 
             */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector
                ("[name = 'frame-left']")));

            IJavaScriptExecutor jsExecutor = (IJavaScriptExecutor)webDriver;
            var currentFrame = jsExecutor.ExecuteScript("return self.name");
            Console.WriteLine(currentFrame);
        }
        [Test, Order(2)]
        public void test_frame_middle()
        {
            String test_url = "http://the-internet.herokuapp.com/nested_frames";

            WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(10));

            webDriver.Url = test_url;

            /**************** Switching to the Left Frame ****************/
            /* Switch to the Parent frame before switching to any of the Child frames */
            webDriver.SwitchTo().ParentFrame();

            /* Since the top frame is a Framset, switch to that frameset first */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name = 'frame-top']")));

            /* As we are already in the frameset, we can now switch to the new frame */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name = 'frame-middle']")));

           

        }

        [Test, Order(3)]
        public void test_frame_right()
        {
            String test_url = "http://the-internet.herokuapp.com/nested_frames";

            WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(10));

            webDriver.Url = test_url;

            /**************** Switching to the Left Frame ****************/
            /* Switch to the Parent frame before switching to any of the Child frames */
            webDriver.SwitchTo().ParentFrame();

            /* Since the top frame is a Framset, switch to that frameset first */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name = 'frame-top']")));

            /* As we are already in the frameset, we can now switch to the new frame */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name = 'frame-right']")));

          }

        [Test, Order(4)]
        public void test_single_frame()
        {
            String test_url = "http://the-internet.herokuapp.com/nested_frames";

            WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(10));

            webDriver.Url = test_url;

            /**************** Switching to the Left Frame ****************/
            /* Switch to the Parent frame before switching to any of the Child frames */
            webDriver.SwitchTo().ParentFrame();

            /* Directly switch to the new frame */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name = 'frame-bottom']")));

        }
        [TearDown]
        public void CloseBrowser()
        {
            webDriver.Quit();
        }

    }
}
