﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    [TestFixture]
    class DynamicWebTableDemo
    {

        private IWebDriver webDriver;
        private String test_url;
        //Instance of extents reports
        //Install-Package ExtentReports -Version 2.40.2
        public ExtentReports extent;

        public static ExtentTest test;



        [OneTimeSetUp]

        public void StartReport()
        {
            //To obtain the current solution path/project path

            string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;

            string actualPath = pth.Substring(0, pth.LastIndexOf("bin"));

            string projectPath = new Uri(actualPath).LocalPath;



            //Append the html report file to current project path

            string reportPath = projectPath + "Reports\\TestRunReport.html";

            Debug.WriteLine(reportPath);

            //Boolean value for replacing exisisting report

            extent = new ExtentReports(reportPath, true);



            //Add QA system info to html report

            extent.AddSystemInfo("SVS", "localhost")

                .AddSystemInfo("Environment", "Windows")

                .AddSystemInfo("Username", "Parameswari");



            //Adding config.xml file

            extent.LoadConfig(projectPath + "Extent-Config.xml");



        }
        
        
        
        
        [SetUp]
        public void InitialSetup()
        {
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            webDriver.Manage().Window.Maximize();
            test_url = "https://www.marketwatch.com/tools/stockresearch/globalmarkets/intIndices.asp";

            
        }

        [Test]
        public void TestTableData()
        {
            webDriver.Url = test_url;
            IList<IWebElement> cells;
            //Start Report

            test = extent.StartTest("Dynamic Web Table");

            //Log 'info'

            test.Log(LogStatus.Info, "Dynamic Web Table demo");
            IList<IWebElement> rows=webDriver.FindElements(By.XPath("//*[@id='intindices']/table[3]/tbody/tr"));
            foreach(IWebElement row in rows)
            {
               cells= row.FindElements(By.TagName("td"));
                foreach(IWebElement cell in cells)
                {
                    Debug.WriteLine(cell.Text);
                }
            }
            test.Log(LogStatus.Pass, "Test Passed");


        }
        [TearDown]
        public void CleanUp()
        {
            //StackTrace details for failed Testcases

            var status = TestContext.CurrentContext.Result.Outcome.Status;

            var stackTrace = "" + TestContext.CurrentContext.Result.StackTrace + "";
            var errorMessage = TestContext.CurrentContext.Result.Message;



            if (status == TestStatus.Failed)

            {

                test.Log(LogStatus.Fail, status + errorMessage);

            }

            //End test report

           extent.EndTest(test);
            webDriver.Close();
        }

        [OneTimeTearDown]

        public void EndReport()

        {

            //End Report

            extent.Flush();

            extent.Close();

        }

    }
}
