﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    [TestFixture]
    class FileUploadDemo
    {

        private IWebDriver webDriver;
        private String test_url;
        [SetUp]
        public void InitialSetup()
        {
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            webDriver.Manage().Window.Maximize();
            test_url = "https://blueimp.github.io/jQuery-File-Upload/";
        }

        [Test]
        public void FileUploadTest()
        {
            webDriver.Url = test_url; 
            IWebElement addFile = webDriver.FindElement(By.XPath(".//input[@type='file']"));
            addFile.SendKeys("C:\\Users\\Balasubramaniam\\Pictures\\admk.jpg");

            webDriver.FindElement(By.XPath(".//span[text()='Start upload']")).Click();
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
            String data = webDriver.FindElement(By.XPath("//*[@id='fileupload']/table/tbody/tr/td[1]/span/a")).GetAttribute("title");
            Assert.AreEqual(data, "admk.jpg");

        }





        [TearDown]
        public void CleanUp()
        {
            webDriver.Close();
        }

    }
}
