﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    [TestFixture]
    class AlertDemo
    {
        private IWebDriver webDriver;
        private IWebElement element;
        private String test_url;
        [SetUp]
        public void InitialSetup()
        {
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            webDriver.Manage().Window.Maximize();
            test_url = "https://www.royalsundaram.in/";
        }

        [Test]
        public void AlertTest()
        {
            // Alert Message handling

            webDriver.Url="http://demo.guru99.com/test/delete_customer.php";


            webDriver.FindElement(By.Name("cusid")).SendKeys("53920");
            webDriver.FindElement(By.Name("submit")).Submit();

            // Switching to Alert        
            // accepting javascript alert
            IAlert alert = webDriver.SwitchTo().Alert();
            

            // Capturing alert message.    
            String alertMessage = webDriver.SwitchTo().Alert().Text;

            // Displaying alert message		
            Console.WriteLine(alertMessage);

            // Accepting alert		
            alert.Accept();
        }

        [Test]

        public void DifferentAlerts()
        {
            webDriver.Url="https://www.hyrtutorials.com/p/alertsdemo.html";
            
            // Alert popups  
            webDriver.FindElement(By.Id("alertBox")).Click();
            String popupText = webDriver.SwitchTo().Alert().Text;
            Assert.AreEqual(popupText, "I am an alert box!");
            webDriver.SwitchTo().Alert().Accept();
            String alertBoxOutput = webDriver.FindElement(By.Id("output")).Text;
            Assert.AreEqual(alertBoxOutput, "You selected alert popup");



            // Confirmation popups  
            webDriver.FindElement(By.Id("confirmBox")).Click();
            popupText = webDriver.SwitchTo().Alert().Text;
            Assert.AreEqual(popupText, "Press a button!");
            webDriver.SwitchTo().Alert().Accept();
            alertBoxOutput = webDriver.FindElement(By.Id("output")).Text;
            Assert.AreEqual(alertBoxOutput, "You pressed OK in confirmation popup");
            webDriver.FindElement(By.Id("confirmBox")).Click();
            webDriver.SwitchTo().Alert().Dismiss();
            alertBoxOutput = webDriver.FindElement(By.Id("output")).Text;
            Assert.AreEqual(alertBoxOutput, "You pressed Cancel in confirmation popup");

            // Prompt popups  
            webDriver.FindElement(By.Id("promptBox")).Click();
            popupText = webDriver.SwitchTo().Alert().Text;
            Assert.AreEqual(popupText, "Please enter your name:");
            webDriver.SwitchTo().Alert().SendKeys("Reddy");
            webDriver.SwitchTo().Alert().Accept();
            alertBoxOutput = webDriver.FindElement(By.Id("output")).Text;
            Assert.AreEqual(alertBoxOutput, "You entered text Reddy in propmt popup");
            webDriver.FindElement(By.Id("promptBox")).Click();
            webDriver.SwitchTo().Alert().Dismiss();
            alertBoxOutput = webDriver.FindElement(By.Id("output")).Text;
            Assert.AreEqual(alertBoxOutput, "You pressed Cancel in prompt popup.");
        }




        [TearDown]
        public void CloseBrowser()
        {
            webDriver.Close();
        }
    }
}
