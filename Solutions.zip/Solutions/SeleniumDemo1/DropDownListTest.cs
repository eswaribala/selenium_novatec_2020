﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    [TestFixture]
    class DropDownListTest
    {
        private IWebDriver webDriver;
        [SetUp]
        public void Init()
        {
            // Create a new instance of the Firefox driver
            webDriver = new ChromeDriver("G:/Local disk/TDD/chromedriver_win32");
            // Put an Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1000);
        }


        [Test]
        public void MultiSelectTest()
        {
            
            // Launch the URL
            webDriver.Url = "http://newtours.demoaut.com/";
            webDriver.FindElement(By.Name("userName")).SendKeys("eswaribala");
            webDriver.FindElement(By.Name("password")).SendKeys("vigneshbala");
            webDriver.FindElement(By.Name("login")).Click();
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1000);

            // Step 3: Select 'Continents' Drop down ( Use Id to identify the element )
            // Find Select element of "Single selection" using ID locator.
            SelectElement oSelection = new SelectElement
                (webDriver.FindElement(By.Name("fromPort")));

            // Step 4:) Select option 'Europe' (Use selectByIndex)
            oSelection.SelectByText("London");

            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1000);

            // Step 5: Select option 'Africa' now (Use selectByVisibleText)
            oSelection.SelectByIndex(2);
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1000);


            // Step 6: Print all the options for the selected drop down and select one option of your choice
            // Get the size of the Select element
            IList<IWebElement> oSize = oSelection.Options;

            int iListSize = oSize.Count;
            // Setting up the loop to print all the options
            for (int i = 0; i < iListSize; i++)
            {
                // Storing the value of the option 
                String sValue = oSelection.Options.ElementAt(i).Text;
                // Printing the stored value
                Console.WriteLine("Value of the Select item is : " + sValue);

                // Putting a check on each option that if any of the option is equal to 'Africa" then select it 
                if (sValue.Equals("Frankfurt"))
                {
                    oSelection.SelectByIndex(i);
                    break;
                }

            }

        }

        [TearDown]
        public void CleanUp()
        {
            webDriver.Close();
        }

    }
}
