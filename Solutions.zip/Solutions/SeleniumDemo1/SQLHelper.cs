﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    class SQLHelper
    {
        public static SqlConnection GetConnection()
        {
            String connstring = ConfigurationManager.ConnectionStrings["svsconn"].ConnectionString;

            return new SqlConnection(connstring);

        }

       

    }
}
