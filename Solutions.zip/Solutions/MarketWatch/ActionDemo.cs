﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketWatch
{

    [TestFixture]
    class ActionDemo
    {

        private IWebDriver webDriver;
        private string url;
        private IDictionary<String, String> dictionary;

        [SetUp]
        public void Init()
        {
            dictionary = ResourceHelper.GetAttributes();
            webDriver = new ChromeDriver(dictionary["driver"].ToString());
            url = dictionary["hyrurl"].ToString();

        }


        [Test]
        public void MouseOverTest()
        {
            webDriver.Url = "http://www.demoqa.com/menu";
            webDriver.Manage().Window.Maximize();
            IWebElement menuOption = webDriver.FindElement(By.XPath("//*[@id='nav']/li[2]/a"));                     
            Assert.AreEqual("Main Item 2", menuOption.Text);
            Actions menuActionsBuilder = new Actions(webDriver);
            IAction menuAction = menuActionsBuilder.MoveToElement(menuOption).Build();
            menuAction.Perform();
            IWebElement subMenuOption = webDriver.FindElement(By.XPath("//*[@id='nav']/li[2]/ul/li[2]/a"));
            Debug.WriteLine(subMenuOption.Text);
            menuAction = menuActionsBuilder.MoveToElement(subMenuOption).Build();
            menuAction.Perform();

        }




        [TearDown]
        public void HYRClose()
        {
            
            webDriver.Close();
        }


    }
}
