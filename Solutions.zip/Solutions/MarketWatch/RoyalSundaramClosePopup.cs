﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketWatch
{
    class RoyalSundaramClosePopup
    {
        private IWebDriver webDriver;
        private string url;
        private IDictionary<String, String> dictionary;

        [SetUp]
        public void Init()
        {
            dictionary = ResourceHelper.GetAttributes();
            webDriver = new ChromeDriver(dictionary["driver"].ToString());
            url = dictionary["rsurl"].ToString();

        }

        [Test]
        public void RSClosePopupTest()
        {
            webDriver.Url = url;
            webDriver.Manage().Window.Maximize();
            String title = "";
            FileStream fs = new FileStream("G:/Local disk/TDD/RSTestResults.csv",
                FileMode.Append,FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            IWebElement element;
           
            
           // wait = new WebDriverWait(webDriver, new TimeSpan(2000));
            //get windows
            foreach (String handle in webDriver.WindowHandles)
            {
                webDriver.SwitchTo().Window(handle);

                try
                {
                    webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1000);
                   element=webDriver.FindElement(By.ClassName("rsgicenter-close"));
                    if (element.Displayed)
                    {
                        element.Click();
                        webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
                        title = webDriver.FindElement(By.CssSelector("h1[class='welcomenote welcomenote_home']")).Text;
                        Assert.IsTrue(title.Contains("Welcome To"));
                        //*[@id="allpagenavbar"]/ul/li[2]/a
                        webDriver.FindElement(By.XPath("//*[@id='allpagenavbar']/ul/li[2]/a")).Click();

                        webDriver.SwitchTo().Window(webDriver.WindowHandles.Last());
                        webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
                        Assert.AreEqual("Renew Policy Online", webDriver.FindElement
                            (By.XPath("//*[@id='dvmain']/h1")).Text);
                        sw.WriteLine("Renew Policy Online,");
                        sw.WriteLine(webDriver.FindElement
                            (By.XPath("//*[@id='dvmain']/h1")).Text + ",");
                        sw.WriteLine("Passed\n");

                    }

                }
                catch(NoSuchElementException exception)
                {
                    Debug.WriteLine(exception.Message);

                }
                catch(Exception  exception)
                {
                    Debug.WriteLine(exception.Message);
                }
               
                try
                {

                    webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1000);
                    element = webDriver.FindElement(By.ClassName("rsgi-close"));

                    if (element.Displayed)
                    {
                        element.Click();
                        webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
                        title = webDriver.FindElement(By.CssSelector("h1[class='welcomenote welcomenote_home']")).Text;
                        Assert.IsTrue(title.Contains("Welcome To"));
                        //*[@id="allpagenavbar"]/ul/li[2]/a
                        webDriver.FindElement(By.XPath("//*[@id='allpagenavbar']/ul/li[2]/a")).Click();

                        webDriver.SwitchTo().Window(webDriver.WindowHandles.Last());
                        webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
                        Assert.AreEqual("Renew Policy Online", webDriver.FindElement
                            (By.XPath("//*[@id='dvmain']/h1")).Text);
                        sw.WriteLine("Renew Policy Online,");
                        sw.WriteLine(webDriver.FindElement
                            (By.XPath("//*[@id='dvmain']/h1")).Text + ",");
                        sw.WriteLine("Passed\n");

                    }

                }
                catch (NoSuchElementException exception)
                {
                    Debug.WriteLine(exception.Message);

                }
                catch (Exception exception)
                {
                    Debug.WriteLine(exception.Message);
                }

            }

            sw.Close();
            fs.Close();

        }

        [TearDown]
        public void RSClose()
        {
          //  webDriver.Close();
        }

    }
}
