﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketWatch
{
    class ResourceHelper
    {
        public static IDictionary<String,String> GetAttributes()
        {
            IDictionary<String, String> dictionary = new Dictionary<String, String>();
            String driver=ConfigurationManager.AppSettings["driver"].ToString();
            String url= ConfigurationManager.AppSettings["url"].ToString();
            String rsurl = ConfigurationManager.AppSettings["rsurl"].ToString();
            String hyrurl = ConfigurationManager.AppSettings["hyrurl"].ToString();
            dictionary.Add("driver", driver);
            dictionary.Add("url", url);
            dictionary.Add("rsurl", rsurl);
            dictionary.Add("hyrurl", hyrurl);
            return dictionary;

        }

    }
}
