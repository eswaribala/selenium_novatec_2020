﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketWatch
{
    [TestFixture]
    class FrameTestDemo
    {
        private IWebDriver webDriver;
        private string url;
        private IDictionary<String, String> dictionary;
        private IJavaScriptExecutor js;

        [SetUp]
        public void Init()
        {
            dictionary = ResourceHelper.GetAttributes();
            webDriver = new ChromeDriver(dictionary["driver"].ToString());
            url = dictionary["url"].ToString();

        }

        [Test]
        public void TopFrameTest()
        {
            webDriver.Url = "http://the-internet.herokuapp.com/nested_frames";
            webDriver.SwitchTo().ParentFrame();
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name='frame-top']")));

            js = (IJavaScriptExecutor)webDriver;
            var frameName = js.ExecuteScript("return self.name");
            Debug.WriteLine(frameName);
            /* As we are already in the frameset, we can now switch to the new frame */
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name = 'frame-middle']")));
            frameName = js.ExecuteScript("return self.name");
            Debug.WriteLine(frameName);

        }


        [Test]
        public void BottomFrameTest()
        {
            webDriver.Url = "http://the-internet.herokuapp.com/nested_frames";
            webDriver.SwitchTo().ParentFrame();
            webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name='frame-bottom']")));
            js = (IJavaScriptExecutor)webDriver;
            var frameName = js.ExecuteScript("return self.name");
            Debug.WriteLine(frameName);
            // webDriver.SwitchTo().ParentFrame();
            try
            {
                webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2000);
                webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector("[name='frame-top']")));
                /* As we are already in the frameset, we can now switch to the new frame */
                webDriver.SwitchTo().Frame(webDriver.FindElement(By.CssSelector
                     ("[name = 'frame-left']")));
                frameName = js.ExecuteScript("return self.name");
                Debug.WriteLine(frameName);

            }
            catch(TimeoutException noSuchFrameException)
            {
                Debug.WriteLine(noSuchFrameException.Message);
            }
            catch(WebDriverException webDriverException)
            {
                Debug.WriteLine(webDriverException.Message);
            }
           


        }

        [TearDown]
        public void FrameClose()
        {
            //webDriver.Close();
        }
        

    }
}
