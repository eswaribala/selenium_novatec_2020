﻿

using Insurance;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabsetupDemo
{
    [TestFixture]
    class TestPolicy
    {
        private Policy _policy;
        //called before every test case executes
        [SetUp]
        public void CreatePolicyInstance()
        {
            this._policy = new Policy();
            this._policy.PolicyId = 472568748;
            this._policy.PolicyName = "Auto Insurance";
            this._policy.InsuredSum = 42000;
            this._policy.Premium = 3000;
            this._policy.IssueDate = new DateTime(2020, 5, 27);
            this._policy.ExpiryDate = new DateTime(2019, 5, 27);
        }

        [Test]
        public void TestPositiveIssueDateAfterCurrentDate()
        {
            int Result= DateTime.Compare(this._policy.IssueDate,  
                DateTime.Today);
            Assert.IsTrue(Result > 0);    
                
        }

        [Test]
        public void TestPositiveExpiryDateAfterIssueDate()
        {
            int Result = DateTime.Compare(this._policy.ExpiryDate, 
                this._policy.IssueDate);
            Assert.IsTrue(Result > 0);

        }
    }
}
