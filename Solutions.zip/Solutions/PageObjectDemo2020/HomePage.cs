﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace PageObjectDemo
{
    public class HomePage
    {
        public IWebDriver webDriver { get; set; }
     

        public HomePage(String path, String url)
        {
            this.webDriver = new ChromeDriver(path);
            this.webDriver.Url = url;

        }

        public void Login(String userName, String password,String url)
        {
            this.webDriver.Url = url;
            this.webDriver.FindElement(By.Name("userName")).SendKeys(userName);
            this.webDriver.FindElement(By.Name("password")).SendKeys(password);
            this.webDriver.FindElement(By.Name("login")).Click();
        }







    }
}
