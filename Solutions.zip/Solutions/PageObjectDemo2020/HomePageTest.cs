﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace PageObjectDemo
{
    [TestFixture]
    class HomePageTest
    {
        private HomePage homePage;

        [OneTimeSetUp]
        public void init()
        {

            homePage = new HomePage("G:/Local disk/TDD/chromedriver_win32", "http://www.newtours.demoaut.com/");
        }

        [Test]
        public void LoginTest()
        {
            this.homePage.Login("eswaribala", "vignesh", "http://www.newtours.demoaut.com/");
        }

        [TearDown]
        public void CleanUp()
        {

        }

    }
}
