﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketWatch
{
    [TestFixture]
    class Fileupload
    {

        private IWebDriver webDriver;
        private string url;
        private IDictionary<String, String> dictionary;

        [SetUp]
        public void Init()
        {
            dictionary = ResourceHelper.GetAttributes();
            webDriver = new ChromeDriver(dictionary["driver"].ToString());
            url = dictionary["hyrurl"].ToString();

        }
        [Test]
        public void FileUploadTest()
        {
            webDriver.Url = "https://blueimp.github.io/jQuery-File-Upload/";
            IWebElement fileUploadElement=webDriver.FindElement(By.XPath("//*[@id='fileupload']/div/div[1]/span[1]/input"));
            fileUploadElement.SendKeys("C:\\Users\\Balasubramaniam\\Pictures\\cognizant.png");
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
            webDriver.FindElement(By.XPath(".//span[text()='Start upload']")).Click();
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
            String name=webDriver.FindElement(By.XPath("//*[@id='fileupload']/table/tbody/tr/td[2]/p/a")).GetAttribute("title");
            Assert.AreEqual("cognizant.png", name);

        }





        [TearDown]
        public void HYRClose()
        {
            
            webDriver.Close();
        }




    }
}
