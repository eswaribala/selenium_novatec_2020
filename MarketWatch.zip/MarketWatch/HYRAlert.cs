﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketWatch
{
    [TestFixture]
    class HYRAlert
    {

        private IWebDriver webDriver;
        private string url;
        private IDictionary<String, String> dictionary;
        private ExtentReports extentReports;
        private ExtentTest extentTest;

        [OneTimeSetUp]
        public void MarketWatchTestReportSetup()
        {
            //To obtain the current solution path/project path

            string path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;

            string actualPath = path.Substring(0, path.LastIndexOf("bin"));

            string projectPath = new Uri(actualPath).LocalPath;

            //Append the html report file to current project path
            string reportFile = "HYRALERTRunReport_" + DateTime.Now.ToString("yyyy-MM-dd-HH_mm_ss");

            string reportPath = projectPath + "Reports\\" + reportFile + ".html";

            Debug.WriteLine(reportPath);

            //Boolean value for replacing exisisting report

            extentReports = new ExtentReports(reportPath, true);

            //Add QA system info to html report
            extentReports.AddSystemInfo("NOVAC", "localhost")

                .AddSystemInfo("Environment", "Windows")

                .AddSystemInfo("Username", "Parameswari");
            //Adding config.xml file
            extentReports.LoadConfig(projectPath + "Extent-Config.xml");

        }
        [SetUp]
        public void Init()
        {
            dictionary = ResourceHelper.GetAttributes();
            webDriver = new ChromeDriver(dictionary["driver"].ToString());
            url = dictionary["hyrurl"].ToString();

        }

        [Test]
        public void HYRSimpleAlertTest()
        {

            webDriver.Url = url;
            //Start Report
            extentTest = extentReports.StartTest("Simple Alert");
            //Log 'info'
            extentTest.Log(LogStatus.Info, "Simple Alert Test");
            webDriver.FindElement(By.Id("alertBox")).Click();
            IAlert simpleAlert=webDriver.SwitchTo().Alert();
            Assert.AreEqual("I am an alert box!", simpleAlert.Text);
            simpleAlert.Accept();
            Assert.AreEqual("You selected alert popup", webDriver.FindElement(By.Id("output")).Text);
            extentTest.Log(LogStatus.Pass, "Simple Alert Test Case Passed");

        }
        [Test]
        public void HYRConfirmAlertTest()
        {

            webDriver.Url = url;
            //Start Report
            extentTest = extentReports.StartTest("Confirm Alert");
            //Log 'info'
            extentTest.Log(LogStatus.Info, "Confirm Alert Test");
            webDriver.FindElement(By.Id("confirmBox")).Click();
            IAlert confirmAlert = webDriver.SwitchTo().Alert();
            Assert.AreEqual("Press a button!", confirmAlert.Text);
            confirmAlert.Accept();
            Assert.AreEqual("You pressed OK in confirmation popup", webDriver.FindElement(By.Id("output")).Text);
            extentTest.Log(LogStatus.Pass, "Confirm Alert Accept Test Case Passed");
            webDriver.FindElement(By.Id("confirmBox")).Click();
            confirmAlert = webDriver.SwitchTo().Alert();
            Assert.AreEqual("Press a button!", confirmAlert.Text);
            confirmAlert.Dismiss();
            Assert.AreEqual("You pressed Cancel in confirmation popup", webDriver.FindElement(By.Id("output")).Text);
            extentTest.Log(LogStatus.Pass, "Confirm Alert Dismiss Test Case Passed");

        }
        [Test]
        public void HYRPromptAlertTest()
        {
            webDriver.Url = url;
            String name = "Parameswari";
            //Start Report
            extentTest = extentReports.StartTest("Prompt Box");
            //Log 'info'
            extentTest.Log(LogStatus.Info, "Prompt Box Test");
            webDriver.FindElement(By.Id("promptBox")).Click();
            IAlert promptAlert = webDriver.SwitchTo().Alert();
            Assert.AreEqual("Please enter your name:", promptAlert.Text);
            promptAlert.SendKeys(name);
            promptAlert.Accept();
            Assert.AreEqual("You entered text "+name+" in propmt popup", webDriver.FindElement(By.Id("output")).Text);
            extentTest.Log(LogStatus.Pass, "Prompt Alert Accept Test Case Passed");
            webDriver.FindElement(By.Id("promptBox")).Click();
            promptAlert = webDriver.SwitchTo().Alert();
            Assert.AreEqual("Please enter your name:", promptAlert.Text);
            promptAlert.Dismiss();
            Assert.AreEqual("You pressed Cancel in prompt popup.", webDriver.FindElement(By.Id("output")).Text);
            extentTest.Log(LogStatus.Pass, "Prompt Alert Dismiss Test Case Passed");
        }


        [TearDown]
        public void HYRClose()
        {
            extentReports.EndTest(extentTest);
            webDriver.Close();
        }

        [OneTimeTearDown]
        public void EndReport()

        {
            //End Report
            extentReports.Flush();
            extentReports.Close();

        }
    }
}
