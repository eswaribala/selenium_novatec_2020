﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using OpenQA.Selenium.Interactions;

namespace MercuryTours
{
    [TestFixture]
    class OpenEMRTest
    {
        private IWebDriver webDriver;
        private String test_url;
        private static Hashtable hashtable;
        private static SqlConnection sqlConnection;
        private static SqlCommand sqlCommand;
        private static SqlDataReader sqlDataReader;
       public IDictionary<string, object> vars { get; private set; }
        private IJavaScriptExecutor js;

        [SetUp]
        public void Initialie()
        {
            hashtable = ResourceHelper.GetKeyandValues();
            webDriver = new ChromeDriver(hashtable["driver"].ToString());
            test_url= hashtable["openemrurl"].ToString();

        }

        [Test,TestCaseSource("DBData")]
        public void LoginTestUsingDataTable(String data1, String data2)
        {
            webDriver.Url = test_url;
            Debug.WriteLine(data1, data2);
            webDriver.FindElement(By.Id("authUser")).SendKeys(data1);
            webDriver.FindElement(By.Id("clearPass")).SendKeys(data2);
            webDriver.FindElement(By.CssSelector("button[class='btn btn-default btn-lg']")).Click();

        }


        private static IEnumerable<String[]> DBData()
        {
            sqlConnection = ResourceHelper.GetConnection();
            sqlConnection.Open();
            hashtable = ResourceHelper.GetKeyandValues();
            using(sqlConnection)
            {
                sqlCommand = new SqlCommand(hashtable["loginQuery"].ToString(), sqlConnection);
                sqlDataReader=sqlCommand.ExecuteReader();
                while(sqlDataReader.HasRows)
                {
                    Debug.WriteLine("\n{0},\t{1}",sqlDataReader.GetName(0), sqlDataReader.GetName(1));
                    while(sqlDataReader.Read())
                    {
                        Debug.WriteLine("\n{0},\t{1}",sqlDataReader.GetString(0), sqlDataReader.GetString(1));
                        yield return new string[] { sqlDataReader.GetString(0), sqlDataReader.GetString(0) };
                    }
                    sqlDataReader.NextResult();

                }


            }

            
        }


        [Test]
        public void PHPTest()
        {
            
            webDriver.Navigate().GoToUrl("https://www.phptravels.net/home");
            webDriver.Manage().Window.Maximize();
            //webDriver.Manage().Window.Size = new System.Drawing.Size(1306, 708);

            //webDriver.FindElement(By.CssSelector(".flights")).Click();
            //js = (IJavaScriptExecutor)webDriver;
            //js.ExecuteScript("window.scrollTo(0,156)");
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3000);
            IWebElement root1 = webDriver.FindElement(By.ClassName("form-icon-left"));

            //Get shadow root element
            IWebElement shadowRoot1 = expandRootElement(root1);
          

        }


    [Test]
    public void JSTest()
        {
            // open webpage

        webDriver.Url="https://chercher.tech/java/javascript-executor-selenium-webdriver";

            js = (IJavaScriptExecutor)webDriver;

            // get the maximum scroll distance Horizontally
            Object horizontalScrollBar = js.ExecuteScript("return window.scrollMaxX");

            // get the maximum scroll distance Vertically
            Object verticalScrollBar = js.ExecuteScript("return window.scrollMaxY");

            

        }


        [Test]
        public void ActionScript()
        {
            webDriver.Url="http://demo.guru99.com/test/newtours/";
            IWebElement link_Home = webDriver.FindElement(By.LinkText("Home"));
            IWebElement td_Home = webDriver
                    .FindElement(By
                    .XPath("//html/body/div"
                    + "/table/tbody/tr/td"
                    + "/table/tbody/tr/td"
                    + "/table/tbody/tr/td"
                    + "/table/tbody/tr"));

            Actions builder = new Actions(webDriver);
            IAction  mouseOverHome = builder
                    .MoveToElement(link_Home)
                    .Build();

            String bgColor = td_Home.GetCssValue("background-color");
            Debug.WriteLine("Before hover: " + bgColor);
            mouseOverHome.Perform();
            bgColor = td_Home.GetCssValue("background-color");
          Debug.WriteLine("After hover: " + bgColor);
        }


    public IWebElement expandRootElement(IWebElement element)
        {
            IWebElement ele = (IWebElement)((IJavaScriptExecutor)webDriver)
    .ExecuteScript("return arguments[0].shadowRoot", element);
            return ele;
        }

        [TearDown]
        public void CloseConnection()
        {
            webDriver.Close();


        }




    }
}
