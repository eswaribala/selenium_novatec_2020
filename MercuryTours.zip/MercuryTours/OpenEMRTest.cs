﻿using Microsoft.Office.Interop.Excel;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace MercuryTours
{
    [TestFixture]
    class OpenEMRTest
    {
        private IWebDriver webDriver;
        private String test_url;
        private Hashtable hashtable;
        private SqlConnection sqlConnection;
        private DataTable dataTable;
        private SqlCommand sqlCommand;
        private SqlDataReader sqlDataReader;


        [SetUp]
        public void Initialie()
        {
            hashtable = ResourceHelper.GetKeyandValues();
            webDriver = new ChromeDriver(hashtable["driver"].ToString());
            test_url= hashtable["openemrurl"].ToString();

        }

        [Test]
        public void LoginTestUsingDataTable()
        {
            webDriver.Url = test_url;
            sqlConnection = ResourceHelper.GetConnection();
            sqlConnection.Open();
            using(sqlConnection)
            {
                sqlCommand = new SqlCommand("select * from OPENEMR_USERS",
                    sqlConnection);
                sqlDataReader = sqlCommand.ExecuteReader();
                


            }




        }

        [TearDown]
        public void CloseConnection()
        {
            webDriver.Close();


        }




    }
}
